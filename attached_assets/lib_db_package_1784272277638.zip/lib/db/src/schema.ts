import { pgTable, serial, text, timestamp, doublePrecision, date, integer, boolean } from "drizzle-orm/pg-core";

// One row per physical ESP32 unit / household meter you're tracking
export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  deviceKey: text("device_key").notNull().unique(), // secret the ESP32 sends to authenticate itself
  name: text("name"), // e.g. "Home meter", "Room 2"
  tariffRatePerKwh: doublePrecision("tariff_rate_per_kwh").notNull().default(8.0), // your local ₹/kWh rate
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Raw firehose — every reading the ESP32 sends, e.g. every 30-60 seconds
export const readings = pgTable("readings", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull().references(() => devices.id),
  powerWatts: doublePrecision("power_watts").notNull(), // instantaneous power draw
  recordedAt: timestamp("recorded_at").defaultNow().notNull(),
});

// One row per device per day — computed from `readings`, this is what your
// model trains on and what the prediction functions read from (much cheaper
// than scanning raw readings every time)
export const dailyUsage = pgTable("daily_usage", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull().references(() => devices.id),
  usageDate: date("usage_date").notNull(),
  energyKwh: doublePrecision("energy_kwh").notNull(),
});

// Every prediction your model makes, logged — lets you later compare
// "predicted vs actual" to see how good the model really is
export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull().references(() => devices.id),
  predictionType: text("prediction_type").notNull(), // "end_of_day" | "monthly_bill"
  predictedValue: doublePrecision("predicted_value").notNull(),
  actualValue: doublePrecision("actual_value"), // filled in later once the real number is known
  modelVersion: text("model_version"), // e.g. "linreg-2026-08-01"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
